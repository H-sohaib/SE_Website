


<img style="width: 20% ; margin-left: auto ; margin-right: auto" src="<?php echo e(asset('assets/images/logo.png')); ?>"
    alt="EST logo">
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/components/application-logo.blade.php ENDPATH**/ ?>