<?php if($attributes['data-name']): ?>
    <div class="alert alert-primary p-0 ps-2" role="alert">
        <?php echo explode('-', pathinfo($attributes['data-name'], PATHINFO_BASENAME))[0]; ?>

    </div>
<?php endif; ?>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/components/user-uploaded-pdf.blade.php ENDPATH**/ ?>