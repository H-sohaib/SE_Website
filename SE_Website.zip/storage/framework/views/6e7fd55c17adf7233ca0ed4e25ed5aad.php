<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .pfe-types:hover {
                z-index: 2;
                color: #fff;
                background-color: #0d6efd;
                border-color: #0d6efd;
                border-radius: 3px;
            }

            .item {
                display: flex;
                justify-content: space-between
            }

            .item>li {
                list-style: none;
            }

            .item i {
                font-size: 20px;
                padding: 0 5px
            }

            .item .delete i {
                color: #dc3545;
            }

            .delete {
                background-color: inherit;
            }

            .list-group-item:hover a i {
                color: #fff;
            }

            .edit {
                cursor: pointer;
                padding-left: 5px;
            }
        </style>
     <?php $__env->endSlot(); ?>
    <ul class="list-group">
        <?php $__currentLoopData = $pfe_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pfe_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item list-group-item align-items-center pfe-types">
                <li class="text-capitalize"><?php echo e($pfe_type->type_name); ?></li>

                <div class="d-flex">
                    <a href="<?php echo e(route('admin.pfe_types.edit', ['pfe_type' => $pfe_type])); ?>"><i
                            class="bi bi-pencil-square edit"></i>
                    </a>

                    <form onsubmit="confirmDelete(this , event)" class="m-0 p-0" method="POST"
                        action="<?php echo e(route('admin.pfe_types.destroy', ['pfe_type' => $pfe_type])); ?>">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button class="m-0 p-0 delete" type="submit"><i class="bi bi-trash-fill"></i></button>
                    </form>
                    
                </div>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="p-3 ps-md-5 pe-md-5">
        <form method="POST" class="d-flex justify-content-center align-items-center"
            action="<?php echo e(route('admin.pfe_types.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-outline flex-fill">
                <label class="form-label" for="form2">Nouveau type de PFE</label>
                <input name="type_name" placeholder="Write here..." type="text" id="form2" class="form-control"
                    required />
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('type_name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('type_name'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </div>
            <button type="submit" class="btn btn-primary ms-2 align-self-end">Ajouter</button>
        </form>
    </div>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.note','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        Lorsque vous supprimez un type, il disparaîtra de l'existence du PFE qui avait déjà ce type supprimé
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/adminViews/pfe_type_index.blade.php ENDPATH**/ ?>