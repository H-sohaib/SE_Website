<div class="my-linkedin p-0 m-0 ps-2 text-left mt-auto" role="alert">
    Made By
    <a href="https://www.linkedin.com/in/harraoui-sohaib-89849b246/" class="alert-link ms-1">
        <i class="bi bi-linkedin"></i>
    </a>
    <a href="https://harraouisohaib.pythonanywhere.com/" class="alert-link ms-1 me-1">
        <i class="bi bi-globe2 fw-bold"></i>
    </a>
    <span class="fw-bold">HARRAOUI Sohaib</span>

</div>



<?php /**PATH E:\WorkSpace\SE_Website\resources\views/components/my-linkedin.blade.php ENDPATH**/ ?>