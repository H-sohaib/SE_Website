<?php if (isset($component)) { $__componentOriginal7442783a15dff2b0d32f2947a462c2e2 = $component; } ?>
<?php $component = App\View\Components\BaseLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BaseLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .portfolio .portfolio-item .portfolio-info button:hover {
                color: red !important;
            }
        </style>


        
     <?php $__env->endSlot(); ?>
    <a href="<?php echo e(route('admin.pfe_exemples.create')); ?>" class="btn btn-primary">Ajouter nouvelle PFE Exemple</a>
    <!-- ======= PFE Exemple Section ======= -->
    <section id="pfe" class="portfolio">
        <div class="container" data-aos="fade-up">

            <div class="section-title">
                <h2>PFE</h2>
                <h3>Quelques réalisation <span>PFE</span></h3>
                <p></p>
            </div>

            <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">
                <?php $__currentLoopData = $pfe_exemples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pfe_exemple): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 portfolio-item <?php echo e($pfe_exemple->filter_type); ?>">
                        <img src="<?php echo e(asset('storage/' . str_replace('public/', '', $pfe_exemple->image_path))); ?>"
                            class="img-fluid" alt="">
                        <div class="portfolio-info ">
                            <h4><?php echo e($pfe_exemple->name); ?></h4>
                            <p> <?php echo e($pfe_exemple->description); ?> </p>
                            <form method="post" style="border: none"
                                action="<?php echo e(route('admin.pfe_exemples.destroy', ['pfe_exemple' => $pfe_exemple])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class=" preview-link" title="<?php echo e($pfe_exemple->name); ?>"><i
                                        class="bi bi-trash-fill"></i></button>
                            </form>
                            <a href="portfolio-details.html" class="details-link" title="More Details"><i
                                    class="bi bi-arrow-down"></i></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $component = $__componentOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/admin/pfe_index.blade.php ENDPATH**/ ?>