<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <h4>Bienvenue <?php echo e($user->name); ?> sur le tableau de bord</h4>
        <p>
            Ici, vous avez un contrôle total sur le contenu des différentes sections du site web.
            Vous pouvez créer, mettre à jour ou supprimer du contenu pour personnaliser l'expérience utilisateur..</p>
        <hr />
        <h4>Exemples PFE</h4>
        <p>Dans cette section, vous pouvez ajouter un nouvel exemple de PFE pour l'afficher dans la section "Quelques
            réalisations PFE" de la page des visiteurs. Vous pouvez également supprimer ou mettre à jour un exemple de
            PFE existant. Lors de la création, vous pouvez définir le nom du PFE, sa description (facultative), une
            image, le rapport du projet ou tout autre fichier PDF expliquant les détails du projet. Enfin, vous pouvez
            spécifier un type de PFE. Nous utilisons ce type pour créer un filtre permettant de séparer les projets en
            fonction du domaine du projet (WEB, Arduino, etc.) par exemple.</p>
        <hr />
        <h4>PFE Types</h4>
        <p>Dans cette section, vous pouvez ajouter les éléments du filtre (type de PFE) dont nous avons parlé dans la
            section "Exemples PFE". Vous pouvez supprimer ou ajouter un nouveau type, et il apparaîtra automatiquement
            dans les sélecteurs de filtres en haut.</p>
        <h4>Organisation modulaire</h4>
        <p>Dans cette section, vous contrôlez le contenu du tableau des modules dans la section "Organisation modulaire"
            de la page des visiteurs.</p>
        <h4>Gestion des admins</h4>
        <p>Dans cette section, vous pouvez ajouter d'autres comptes d'administrateurs pour accéder à ce tableau de bord
            ou supprimer un compte existant.
        </p>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/adminViews/index.blade.php ENDPATH**/ ?>