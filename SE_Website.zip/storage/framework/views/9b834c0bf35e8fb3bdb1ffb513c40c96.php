<p class="text-danger mt-2"><strong>Note : </strong> <?php echo e($slot); ?>

</p>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/components/note.blade.php ENDPATH**/ ?>