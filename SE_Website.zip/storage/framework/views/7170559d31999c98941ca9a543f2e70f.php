<div class="alert alert-primary" role="alert">
    Made By Harraoui Sohaib<a href="" class="alert-link"><i class="bi bi-linkedin"></i></a>
</div>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/components/my_linkedin.blade.php ENDPATH**/ ?>