    <!-- ======= Header ======= -->
    <header id="header" class="d-flex align-items-center justify-content-between ps-3 pe-3 fixed-top">
        

        <h1 class="logo ms-3"><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt=""></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt=""></a>-->
        <nav id="navbar" class="navbar  me-5">
            <ul>
                <li class="admin-links"><a class="nav-link " href="<?php echo e(route('admin.index')); ?>">Accueil</a></li>
                <li class="admin-links"><a class="nav-link scrollto"
                        href="<?php echo e(route('admin.organisation_modulaire.index')); ?>">Organisation
                        modulaire</a></li>
                <li class="admin-links">
                    <a class="nav-link scrollto" href="<?php echo e(route('admin.pfe_types.index')); ?>">PFE Types</a>
                </li>
                <li class="admin-links">
                    <a class="nav-link scrollto" href="<?php echo e(route('admin.pfe_exemples.index')); ?>">Exemples PFE</a>
                </li>
                <li class="admin-links">
                    <a class="nav-link scrollto" href="<?php echo e(route('admin.admin_management.index')); ?>">Gestion des
                        admins</a>
                </li>
                <li><a class="nav-link scrollto" href="<?php echo e(route('home')); ?>">Page des visiteurs</a></li>
                <li><a class="nav-link scrollto" href="<?php echo e(route('profile.edit')); ?>">Profile</a></li>
                <li>
                    <form class="m-0 p-0" method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-link scrollto">Log Out</button>
                    </form>
                </li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
        <!-- .navbar -->

        
    </header>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/layouts/admin/navigation.blade.php ENDPATH**/ ?>