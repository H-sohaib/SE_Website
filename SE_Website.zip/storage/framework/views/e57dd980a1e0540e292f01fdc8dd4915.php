<?php echo e($slot); ?>

<?php /**PATH E:\WorkSpace\SE_Website\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>