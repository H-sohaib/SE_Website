<?php if (isset($component)) { $__componentOriginal7442783a15dff2b0d32f2947a462c2e2 = $component; } ?>
<?php $component = App\View\Components\BaseLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BaseLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container d-flex justify-content-center">
        <form method="POST" action="<?php echo e(route('admin.pfe_exemples.store')); ?>" enctype="multipart/form-data"
            class="row g-3 m-0 mt-5 w-50">
            <?php echo csrf_field(); ?>
            
            <div class="col-12">
                <label for="inputAddress" class="form-label">Titre d'exemple réalisation PFE</label>
                <input name="name" type="text" class="form-control" required>
            </div>
            
            <div class="col-12">
                <div class="form-outline">
                    <label class="form-label" for="textAreaExample">Description</label>
                    <textarea name="description" class="form-control" id="textAreaExample1" rows="4"></textarea>
                </div>
            </div>
            
            <div class="col-6">
                <label class="form-label" for="customFile">Image de PFE</label>
                <input name="image" type="file" class="form-control" required />
            </div>
            
            <div class="col-6">
                <label class="form-label" for="customFile">Rapport de PFE</label>
                <input name="pdf" type="file" class="form-control" id="customFile" />
            </div>
            
            <div class="col-6">
                <label for="inputState" class="form-label">Type de PFE</label>
                <select name="filter_type" class="form-select" required>
                    <option value="" selected>Choose...</option>
                    <option value="filter-arduino">Arduino</option>
                    <option value="filter-web">Web</option>
                    <option value="filter-ai">Ai</option>
                </select>
            </div>

            <div class="col-12">
                <button type="submit" class="btn btn-primary">Create</button>
            </div>

        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $component = $__componentOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/admin/pfe_create.blade.php ENDPATH**/ ?>