<?php if (isset($component)) { $__componentOriginal7442783a15dff2b0d32f2947a462c2e2 = $component; } ?>
<?php $component = App\View\Components\BaseLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('base-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\BaseLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .drop-ul-margin-fix {
                margin-left: 0px !important;
            }

            /* Large devices (desktops, 992px and up) */
            @media (min-width: 992px) {
                .drop-ul-margin-fix {
                    margin-left: -100px !important;
                }
            }
        </style>
     <?php $__env->endSlot(); ?>
    <!-- ======= Header ======= -->
    <header id="header" class="d-flex align-items-center justify-content-between ps-3 pe-3">
        

        <h1 class="logo ms-3"><img src="assets/images/logo.png" alt=""></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html" class="logo"><img src="assets/img/logo.png" alt=""></a>-->

        <nav id="navbar" class="navbar">
            <ul>
                <li><a class="nav-link scrollto active" href="#hero">Accueil</a></li>
                <li><a class="nav-link scrollto" href="#presentation">Présentation</a></li>
                <li><a class="nav-link scrollto" href="#marche">Marché</a></li>
                <li><a class="nav-link scrollto" href="#objectifs">Objectifs</a></li>
                <li class="dropdown org-dropdown"><a class="org">Organisation<i class="bi bi-chevron-down"></i></a>
                    <ul>
                        <li><a class="nav-link scrollto" href="#organisation">Organisation</a></li>
                        <li><a class="nav-link scrollto" href="#organisation-modulaire">Organisation modulaire</a></li>
                    </ul>
                </li>
                <li><a class="nav-link scrollto" href="#competences">Compétences</a></li>

                <li class="dropdown other-dropdown"><a class="org">Autre<i class="bi bi-chevron-down"></i></a>

                    <ul class="drop-ul-margin-fix">

                        <li class="dropdown acces-dropdown"><a class="org">
                                Conditions d’accès <i class="bi bi-chevron-right"></i>
                            </a>
                            <ul>
                                <li><a class="nav-link scrollto" href="#modalites">Modalités d’admission</a></li>
                                <li><a class="nav-link scrollto" href="#acces">Accès par passerelles</a></li>
                            </ul>
                        </li>

                        <li><a class="nav-link scrollto" href="#debouches">Débouchés de la filière</a></li>
                        <li><a class="nav-link scrollto" href="#pfe">Quelques réalisation PFE</a></li>
                    </ul>

                </li>

                <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
        </nav>
        <!-- .navbar -->

        
    </header><!-- End Header -->

    <!-- ======= Hero Section ======= -->
    <section id="hero" class="d-flex align-items-center text-center text-sm-start">
        <div class="container" data-aos="zoom-out" data-aos-delay="100">
            <h2 class="fw-bold">L'École Supérieure de Technologie de Fès offre</h2>
            <h1>La filière DUT<span> Systèmes Embarqués (SE)</span></h1>
            <h2 class="fw-bold">Département Génie Électrique & Systèmes Intelligents</h2>
        </div>
    </section><!-- End Hero -->

    <main id="main">

        <!-- ======= Présentation Section ======= -->
        <section id="presentation" class="about">
            <div class="container">

                <div class="section-title">
                    <h2>Présentation</h2>
                    <h3>Présentation de la <span>filière</span></h3>
                    <p></p>
                </div>

                <div class="row justify-content-center">
                    <p class="col-lg-12 text-center mb-0">
                        La filière Systèmes Embarqués est une filière très attractive et à la pointe de la technologie
                        actuelle sachant que la plupart des systèmes informatiques actuels sont embarqués dans les
                        téléphones portables, les moyens de transport, les équipements médicaux, les appareils ménagers,
                        les robots, etc. C’est une filière d’avenir et qui commence à faire son petit chemin et se faire
                        connaitre. Elle offre plusieurs possibilités de poursuite des études au niveau national et
                        international.
                    </p>
                </div>
            </div>

            </div>
        </section>

        <!-- ======= Marché d’emploi Section ======= -->
        <section id="marche" class="services section-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Marché</h2>
                    <h3>Marché d’<span>emploi</span></h3>
                    <p></p>
                </div>

                <div class=" justify-content-center">
                    <p class="col-lg-12 text-center mb-0">
                        Le marché des systèmes embarqués est énorme et la demande de l'industrie en experts qualifiés
                        dans ce domaine ne cesse de croître particulièrement après l’implantation de plusieurs poids
                        lourds du secteur d’automobile et d’aéronautique au Maroc. Ce secteur compte désormais parmi les
                        leviers prometteurs du Royaume en matière de croissance et de création d’emplois.
                    </p>
                </div>

            </div>
        </section>

        <!-- ======= Objectif Section ======= -->
        <section id="objectifs" class="about">
            <div class="container">

                <div class="section-title">
                    <h2>Objectif</h2>
                    <h3>L'objectif de la <span>formation</span></h3>
                    <p></p>
                </div>

                <div class="row flex-column-reverse flex-lg-row">
                    <div class="col-lg-4 mb-4 mb-lg-0 d-flex justify-content-center align-items-lg-center"
                        data-aos="fade-right" data-aos-delay="100">
                        <img src="assets/images/objectif.png" class="img-fluid" alt="">
                    </div>
                    <p class="col-lg-8 fs-6 text-center text-lg-start">
                        Aujourd'hui, la majorité des ordinateurs sont embarqués, on les trouve dans les téléphones
                        portables, les
                        consoles de jeux, les voitures, les avions, les équipements médicaux; les appreils ménagers, les
                        robots,
                        etc...
                        Filière DUT Systeme Embarqués (SE)
                        L'objectif de la Filière Systèmes Embarqués est de
                        former des techniciens supérieurs dans le domaine
                        des systèmes embarqués de haut niveau technique et
                        des compétences polyvalentes leurs permettant de
                        seconder les ingénieurs dans le domaine de l'aérono-
                        tique, de l'automobile, médical, domotique ou
                        encore multimédia. <br>

                        La filière Systèmes Embarqués organisée en quatre
                        semestres est sanctionnée par un Diplôme Universitaire de Technologie (DUT).
                        Cette formation apporte aux étudiants des connaissances théoriques dans le domaine
                        d'électronique et
                        de l'informatique embarquée qui sont complétées et
                        approfondies par de nombreux travaux pratiques et
                        projets. Les thématiques abordées couvrent un
                        specte large, depuis le matériel (langages de sescription matériel, architectures
                        reconfigurables, support
                        d'exécution) jusqu'aux aspects logiciels (programma-
                        tion d'un système à micro-processeur, compilation,
                        programmation mobile) en incluant également des
                        connaissances en automatiques, automatismes
                        Industriels et réseaux locaux.
                    </p>
                </div>
            </div>

            </div>
        </section><!-- End About Section -->

        <!-- ======= Organisation Section ======= -->
        <section id="organisation" class="services section-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Organisation</h2>
                    <h3>L'organisation des études dans la <span>filière</span></h3>
                    <p></p>
                </div>

                <div class=" justify-content-center">
                    <p class="col-lg-12 text-center mb-0">
                        La filière Systèmes Embarqués organisée en quatre semestres est sanctionnée par un Diplôme
                        Universitaire de Technologie (DUT). Cette formation apporte aux étudiants des connaissances
                        théoriques dans le domaine d’électronique et de l’informatique embarquée qui sont complétées et
                        approfondies par de nombreux travaux pratiques et projets. Les thématiques abordées couvrent un
                        spectre large, depuis le matériel (langages de description matériel, architectures
                        reconfigurables, support d’exécution) jusqu’aux aspects logiciels (programmation d’un système à
                        micro-processeur, compilation, programmation mobile) en incluant également des connaissances en
                        modélisation.
                    </p>
                </div>

            </div>
        </section>

        
        <section id="organisation-modulaire" class="section-bg">
            <div class="container">
                <div class="section-title mt-4">
                    <h2>Organisation modulaire</h2>
                    <h3><span></span></h3>
                    <p></p>
                </div>

                <div class="row justify-content-center">
                    <div class="overflow-auto col-12">
                        <table class="table mb-0">
                            <thead style="background-color: #002d72;">
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col">N°</th>
                                    <th scope="col">Intitulé</th>
                                    <th scope="col">Élément(s) de module</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $semestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semestre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <?php
                                        $module_with_no_matiere = 0;
                                    ?>
                                    <?php $__currentLoopData = $semestre->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($module->matieres->isEmpty()): ?>
                                            <?php
                                                $module_with_no_matiere++;
                                            ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <tr>
                                            <td class="text-capitalize"
                                                rowspan="<?php echo e(count($semestre->matieres) + $module_with_no_matiere + 1); ?>">
                                                <?php echo e($semestre->semestre_name); ?>

                                            </td>
                                        </tr>
                                        <?php $__currentLoopData = $semestre->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <?php $first = true ; ?> 
                                            <?php if($module->matieres->count() > 0): ?>
                                                <?php $__currentLoopData = $module->matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    <?php if($first): ?>
                                                        
                                                        <tr>
                                                            
                                                            <td rowspan="<?php echo e(count($module->matieres)); ?>">
                                                                M<?php echo e($module->module_num); ?></td>
                                                            
                                                            <td rowspan="<?php echo e(count($module->matieres)); ?>">
                                                                <?php echo e($module->module_name); ?>

                                                            </td>
                                                            
                                                            <td><?php echo e($matiere->matiere_name); ?></td>
                                                        </tr>
                                                        <?php $first = false ; ?>
                                                    <?php else: ?>
                                                        
                                                        <tr>
                                                            <td><?php echo e($matiere->matiere_name); ?></td>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <tr>
                                                    <td>M<?php echo e($module->module_num); ?></td>
                                                    <td><?php echo e($module->module_name); ?></td>
                                                    <td></td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>

        <!-- ======= Compétences à acquérir Section ======= -->
        <section id="competences" class="about">
            <div class="container">

                <div class="section-title">
                    <h2>Compétences</h2>
                    <h3>Compétences à <span>acquérir</span></h3>
                    <p></p>
                </div>

                <div class="row flex-column-reverse flex-lg-row">
                    <div class="col-lg-4 mb-4 mb-lg-0 d-flex justify-content-center align-items-lg-center"
                        data-aos="fade-right" data-aos-delay="100">
                        <img src="assets/images/skills.jpg" class="img-fluid" alt="">
                    </div>
                    <div class="col-lg-8 fs-6">
                        <p class="text-center text-lg-start">
                            La formation DUT en systèmes embarqués a pour mission de transmettre à ses lauréats des
                            compétences techniques et scientifiques pluridisciplinaires de haut niveau. Une fois
                            terminés
                            avec succès, nos étudiants seront très compétitifs sur le marché du travail national et
                            international en tant que techniciens supérieurs hautement qualifié à fort potentiel
                            capables
                            d’être rapidement opérationnels, de s’adapter facilement à des situations nouvelles et
                            variées,
                            de maîtriser et de suivre l’évolution des nouvelles technologies, de prendre l’initiative,
                            d’avoir un esprit critique et d’être capable d’apporter des solutions innovatrices à la
                            mesure
                            de la compétitivité qui devient de plus en plus rude.
                            Cette filière a été conçue dans le but de développer chez l’étudiant les compétences
                            nécessaires
                            à l’exercice d’un métier dans le secteur industriel à savoir:
                        </p>
                        <ul class="ms-lg-3">
                            <li>Le développement et la conception des Systèmes embarqués.</li>
                            <li>La maitrise et la maintenance des systèmes aéronautiques et automobile.</li>
                            <li>L’automatisation, la régulation industrielle et la commande des procédés.</li>
                            <li>La sécurité des systèmes.</li>
                            <li>La conception et le dimensionnement d’installations industrielles.</li>
                            <li>La gestion de projets.</li>
                        </ul>
                    </div>

                </div>
            </div>

            </div>
        </section>

        <!-- ======= Modalités d’admission Section ======= -->
        <section id="modalites" class="services section-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Modalités</h2>
                    <h3>Modalités d’<span>admission</span></h3>
                    <p></p>
                </div>

                <div class=" justify-content-center">
                    <div class="col-lg-12  mb-0 text-center text-lg-start">
                        <p>
                            <strong>Diplômes requis :</strong> La formation est ouverte aux étudiants titulaires d'un
                            Baccalauréat Sciences
                            Expérimentales options (SPC), Sciences Maths A (SMA) ou Sciences Maths B (SMB), Sciences et
                            Technologies Électriques (STE) , professionnel (bac pro) selon une sélection basée sur les
                            notes obtenues au
                            baccalauréat.
                        </p>
                        <p>
                            <strong>Pré requis pédagogiques spécifiques :</strong> Bon niveau en mathématiques, en
                            physique, en sciences de l’ingénieur (STE) , en matières professionnelles (BAC Pro) et en
                            français.
                        </p>
                    </div>
                </div>

            </div>
        </section>

        <!-- ======= Conditions d’accès Section ======= -->
        <section id="acces" class="services">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>accès</h2>
                    <h3>Accès par <span>passerelles</span></h3>
                    <p></p>
                </div>

                <div class=" justify-content-center">
                    <div class="col-lg-12  mb-0 text-center text-lg-start">
                        <p class="">
                            L’accès aux formations de DUT peut se faire également en S3 sur étude de dossier pour les
                            étudiants issus d’autres établissements de l’enseignement supérieur, satisfaisant aux
                            prérequis
                            précisés dans le descriptif de la filière.
                        </p>

                        <p>
                            <strong>Passerelle avec la filière GE, GI, GIM et RT :</strong>
                            La filière Systèmes embarqués (SE) partage différents enseignements avec plusieurs autres
                            filières de l’établissement en particulier : la filière Génie électrique (GE), Génie
                            informatique (GI), Génie Industriel et Maintenance (GIM) et la filière de Réseau et Télécoms
                            (RT). <br>
                            A l’issue du semestre S1 et S2, une réorientation de l’étudiant entre la filière SE et les
                            filières GE, GI, RT et GIM (Filières de EST Fès) est possible.
                        </p>

                        <p>
                            <strong>D’autres passerelles :</strong>
                            Les filières ouvertes dans les facultés des sciences (FS), les facultés des sciences et
                            techniques (FST) ou les Cycles préparatoires des écoles d’ingénieurs (EI) peuvent être
                            envisagées. Toutefois, toute réorientation requiert l’étude du dossier pédagogique et sa
                            validation par l’équipe pédagogique.
                        </p>
                    </div>
                </div>

            </div>
        </section>

        <!-- ======= Débouchés de la formation Section ======= -->
        <section id="debouches" class="services section-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Débouchés</h2>
                    <h3>Débouchés de la <span>formation</span></h3>
                    <p></p>
                </div>

                <div class="row">
                    <p class="text-center text-lg-start">
                        Cette filière interdisciplinaire vise à donner aux
                        élèves une formation dans le domaine des systèmes
                        embarqués. De manière générale, les débouchés
                        sont nombreux au sein des entreprises des secteurs
                        liés à l'automobile, l'aéronautique et l'espace, les
                        télécommunications en particulire mobiles,
                        l'instrumentation médicale, le conseil en technolo-
                        gies innovantes, le multimédia, électonique grand
                        public.
                        La formation DUT en systèmes embarqués a pour
                        mission de transmettre à ses lauréats des compé-
                        tences techniques et scientifiques pluridiscipli-
                        naires de haut niveau leurs permettant de
                        développer les compétences nécessaires à l'exercice
                        d'un métier dans le secteur industriel à savoir :
                    </p>

                    <ul class="p-0 m-0 ms-2 ms-lg-5 mb-3 debouche">
                        <li>- Le développement et la conception des Systèmes
                            embarqués</li>
                        <li>- La maîtrise et la maitenance des systèmes aéronau-
                            tiques et automobile.</li>
                        <li>- L'automatisation, la régulation industrielle et la
                            commande des procédés;</li>
                        <li>- La sécurité des systèmes;</li>
                        <li>- La conception et le dimensionnement d'installa-
                            tions industrielles;</li>
                        <li>- La gestion de projets ...</li>
                    </ul>

                    <p>
                        Poursuite des études
                        La formation DUT SE est organisée autour de compé-
                        tence en éléctronique et informatique embarquéee
                        complété par des connaissances générales per-
                        mettent aux étudiants une insertion professionnelle
                        immédiate, ou une poursuite d'études vers d'autres
                        formations de l'enseignement supérieur.
                    </p>
                </div>

            </div>
        </section>

        <?php if($pfe_exemples): ?>
            <!-- ======= PFE Exemple Section ======= -->
            <section id="pfe" class="portfolio">
                <div class="container" data-aos="fade-up">

                    <div class="section-title">
                        <h2>PFE</h2>
                        <h3>Quelques réalisation <span>PFE</span></h3>
                        <p></p>
                    </div>

                    <div class="row" data-aos="fade-up" data-aos-delay="100">
                        <div class="col-lg-12 d-flex justify-content-center">
                            <ul id="portfolio-flters">
                                <li data-filter="*" class="filter-active">Tout</li>
                                <?php $__currentLoopData = $pfe_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pfe_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li data-filter=".filter-<?php echo e($pfe_type->type_name); ?>"><?php echo e($pfe_type->type_name); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>

                    <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">
                        <?php $__currentLoopData = $pfe_exemples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pfe_exemple): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                class="col-lg-4 col-md-6 portfolio-item <?php $__currentLoopData = explode('|', $pfe_exemple->types); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e('filter-' . $value); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
                                <img src="<?php echo e(asset($pfe_exemple->image_path)); ?>" class="img-fluid" alt="">
                                <div class="portfolio-info ">
                                    <h4><?php echo e($pfe_exemple->name); ?></h4>
                                    <p> <?php echo e($pfe_exemple->description); ?> </p>
                                    <a href="<?php echo e(asset($pfe_exemple->image_path)); ?>" data-gallery="portfolioGallery"
                                        class="portfolio-lightbox preview-link fs-6 pe-1"
                                        title="<?php echo e($pfe_exemple->name); ?>"><i class="bi bi-arrows-angle-expand"></i>
                                        Aperçu</a>


                                    <?php if($pfe_exemple->pdf_path): ?>
                                        <a href="<?php echo e(route('view_pdf', ['pfe' => $pfe_exemple])); ?>"
                                            class="details-link fs-6" title="View Rapport"><i
                                                class="bi bi-eye-fill"></i>
                                            Voir
                                            le Rapport
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>


        <!-- ======= Contact Section ======= -->
        <section id="contact" class="contact section-bg">
            <div class="container" data-aos="fade-up">

                <div class="section-title">
                    <h2>Contact</h2>
                    <h3><span>Contactez-nous</span></h3>
                    <p></p>
                </div>

                <div class="row" data-aos="fade-up" data-aos-delay="100">
                    <div class="col-lg-6">
                        <div class="info-box mb-4">
                            <i class="bi bi-geo-alt"></i>
                            <h3>Notre adresse</h3>
                            <p>Ecole Supérieure de Technologie BP 2427 Route d’Imouzzer 30000 Fès</p>
                        </div>
                    </div>

                    <div class="col-12 col-lg-6">
                        <div class="info-box  mb-4">
                            <i class="bi bi-envelope"></i>
                            <h3>Email</h3>
                            <p>zakaria.moutakki@usmba.ac.ma</p>
                        </div>
                    </div>

                </div>

                <div class="row" data-aos="fade-up" data-aos-delay="100">

                    <div class="col-lg-6 ">
                        <iframe class="mb-4 mb-lg-0"
                            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d10443.538855840903!2d-4.958476228225645!3d34.00257218183202!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd9f8bbea38bd1cb%3A0x36c2d3aadd24868d!2sHigher%20School%20of%20Technology!5e0!3m2!1sen!2sma!4v1685454466997!5m2!1sen!2sma"
                            allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
                            frameborder="0" style="border:0; width: 100%; height: 384px;"></iframe>
                    </div>

                    <div class="col-lg-6">
                        <form action="<?php echo e(route('sendEmail')); ?>" method="post" role="form"
                            class="php-email-form">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col form-group">
                                    <input type="text" name="name" class="form-control" id="name"
                                        placeholder="Votre Nom" required>
                                </div>
                                <div class="col form-group">
                                    <input type="email" class="form-control" name="email" id="email"
                                        placeholder="Votre Email" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="subject" id="subject"
                                    placeholder="Sujet" required>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
                            </div>
                            <div class="my-3">
                                <div class="loading">Chargement en cours...</div>
                                <div class="error-message"></div>
                                <div class="sent-message">Votre message a été envoyé. Merci !</div>
                            </div>
                            <div class="text-center"><button type="submit">Envoyer le message</button></div>
                        </form>
                    </div>

                </div>

            </div>
        </section><!-- End Contact Section -->

    </main>
    <!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" class="section-bg">

        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-lg-5 col-md-6 footer-contact m-auto">
                        <h3 class="logo text-center text-lg-start"><img class="w-75" src="assets/images/logo.png"
                                alt=""></h3>
                    </div>

                    <div class="col-lg-7 col-md-6 footer-contact m-auto">
                        <p>
                            <i class="bi bi-pin-map me-3 fs-5 text-primary"></i><strong>Adresse :</strong> Ecole
                            Supérieure de
                            Technologie BP
                            2427 Route d’Imouzzer 30000
                            Fès <br>
                            <i class="bi bi-pin-map me-3 fs-5 text-primary"></i><span class="text-start">المدرسة
                                العليا
                                للتيكنولوجيا ص ب
                                2427
                                طريق إيموزار 30000 فاس</span>
                            <br>
                            <i class="bi bi-telephone me-3 fs-5 text-primary"></i><strong>Tel :</strong> +212 5 35 60
                            05 84 <br>
                            <i class="bi bi-telephone me-3 fs-5 text-primary"></i><strong>Fax :</strong> +212 5 35 60
                            05 88 <br>
                            <i class="bi bi-envelope-at me-3 fs-5 text-primary"></i><strong>E-mail :</strong>
                            support.est@usmba.ac.ma<br>
                            <i class="bi bi-globe me-3 fs-5 text-primary"></i><strong>Site Web :</strong> <a
                                href="http://www.est-usmba.ac.ma/">www.est-usmba.ac.ma</a><br>
                        </p>
                    </div>


                </div>
            </div>
        </div>

    </footer><!-- End Footer -->

    <div id="preloader"></div>
    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2)): ?>
<?php $component = $__componentOriginal7442783a15dff2b0d32f2947a462c2e2; ?>
<?php unset($__componentOriginal7442783a15dff2b0d32f2947a462c2e2); ?>
<?php endif; ?>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/index.blade.php ENDPATH**/ ?>