<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .pfe-types:hover {
                z-index: 2;
                color: #fff;
                background-color: #0d6efd;
                border-color: #0d6efd;
                border-radius: 3px;
            }

            .item {
                display: flex;
                justify-content: space-between
            }

            .item>li {
                list-style: none;
            }

            .item i {
                font-size: 20px;
                padding: 0 5px
            }

            .item .delete i {
                color: #dc3545;
            }

            .delete {
                background-color: inherit;
            }

            .list-group-item:hover a i {
                color: #fff;
            }

            .input {
                padding: 0px 10px;
                padding-left: 10px;
            }

            .input:focus {
                border: 2px solid red
            }
        </style>
     <?php $__env->endSlot(); ?>
    <ul class="list-group">


        <form class="m-0 p-0" method="POST"
            action="<?php echo e(route('admin.pfe_types.update', ['pfe_type' => $editable_type])); ?>">
            <?php echo method_field('PATCH'); ?>
            <?php echo csrf_field(); ?>
            <div class="item list-group-item align-items-center">
                <input name="type_name" autofocus class="form-control w-75" value="<?php echo e($editable_type->type_name); ?>" />
                <div class="d-flex">
                    <button class="m-0 p-2 pt-1 pb-1 btn btn-primary" type="submit">Update</button>
                </div>
            </div>
        </form>




        <?php $__currentLoopData = $pfe_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pfe_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item list-group-item align-items-center pfe-types">
                <li class="text-capitalize"><?php echo e($pfe_type->type_name); ?></li>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </ul>

    <div class="w-100 d-flex justify-content-center mt-3">
        <a href="<?php echo e(route('admin.pfe_types.index')); ?>">
            <button class="ms-auto me-auto btn btn-primary" type="submit">Annuler</button>
        </a>
    </div>



    

    

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/adminViews/pfe_type_edit.blade.php ENDPATH**/ ?>