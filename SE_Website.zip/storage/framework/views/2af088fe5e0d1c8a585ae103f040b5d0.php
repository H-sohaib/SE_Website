<!DOCTYPE html>
<html>

<head>
    <title>AllPHPTricks.com</title>
</head>

<body>
    <h1><?php echo e($mailData['title']); ?></h1>
    <p><?php echo e($mailData['body']); ?></p>
</body>

</html>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/emails/testMail.blade.php ENDPATH**/ ?>