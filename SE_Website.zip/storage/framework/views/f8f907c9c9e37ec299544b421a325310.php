<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .edit {
                cursor: pointer;
                color: blue
            }

            td>span:focus {
                padding: 5px;
                outline: none;
                border: 2px solid blue;
                border-radius: 3px;
            }

            .submit {
                /* position: relative;
                left: 50%;
                transform: translateX(-50%) */
            }

            a[role="button"] {
                position: relative;
                left: 0;
            }

            .delete {
                color: red;
                cursor: pointer;
            }
        </style>
     <?php $__env->endSlot(); ?>
    
    <div class="alert d-none" role="alert">
    </div>

    <section id="organisation-modulaire" class="section-bg mt-0 p-0">
        <div class="container">
            <div class="section-title pb-1">
                <h2>Organisation modulaire</h2>
                <h3><span></span></h3>
                <p></p>
            </div>

            <div class="row justify-content-center">
                <div class="overflow-auto col-12">
                    <table class="table mb-0">
                        <thead style="background-color: #002d72;">
                            <tr>
                                <th scope="col"></th>
                                <th scope="col">N°</th>
                                <th scope="col">Intitulé</th>
                                <th scope="col">Élément(s) de module</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $semestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semestre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php
                                    $module_with_no_matiere = 0;
                                ?>
                                <?php $__currentLoopData = $semestre->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($module->matieres->isEmpty()): ?>
                                        <?php
                                            $module_with_no_matiere++;
                                        ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <tr>
                                        <td class="text-capitalize"
                                            rowspan="<?php echo e(count($semestre->matieres) + $module_with_no_matiere + 1); ?>">
                                            <?php echo e($semestre->semestre_name); ?>

                                        </td>
                                    </tr>
                                    <?php $__currentLoopData = $semestre->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <?php $first = true ; ?> 
                                        <?php if($module->matieres->count() > 0): ?>
                                            
                                            <?php $__currentLoopData = $module->matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                
                                                <?php if($first): ?>
                                                    
                                                    <tr>
                                                        
                                                        <td rowspan="<?php echo e(count($module->matieres)); ?>">
                                                            <span class="module-num"
                                                                data-moduleNum="<?php echo e($module->id); ?>">M<?php echo e($module->module_num); ?></span>
                                                            <i class="bi bi-pencil-square edit"></i>
                                                        </td>
                                                        
                                                        <td rowspan="<?php echo e(count($module->matieres)); ?>">
                                                            <span
                                                                data-module="<?php echo e($module->id); ?>"><?php echo e($module->module_name); ?></span>
                                                            <i class="bi bi-pencil-square edit"></i>
                                                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.delete-form','data' => ['route' => ''.e(route('admin.organisation_modulaire.destroy', ['organisation_modulaire' => $module])).'','value' => 'module']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('delete-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('admin.organisation_modulaire.destroy', ['organisation_modulaire' => $module])).'','value' => 'module']); ?>
                                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                                        </td>
                                                        
                                                        <td>
                                                            <span
                                                                data-matiere="<?php echo e($matiere->id); ?>"><?php echo e($matiere->matiere_name); ?></span>
                                                            <i class="bi bi-pencil-square edit"></i>
                                                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.delete-form','data' => ['route' => ''.e(route('admin.organisation_modulaire.destroy', ['organisation_modulaire' => $matiere])).'','value' => 'matiere']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('delete-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('admin.organisation_modulaire.destroy', ['organisation_modulaire' => $matiere])).'','value' => 'matiere']); ?>
                                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                                        </td>
                                                    </tr>
                                                    <?php $first = false ; ?>
                                                <?php else: ?>
                                                    
                                                    <tr>
                                                        <td>
                                                            <span
                                                                data-matiere="<?php echo e($matiere->id); ?>"><?php echo e($matiere->matiere_name); ?></span>
                                                            <i class="bi bi-pencil-square edit"></i>
                                                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.delete-form','data' => ['route' => ''.e(route('admin.organisation_modulaire.destroy', ['organisation_modulaire' => $matiere])).'','value' => 'matiere']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('delete-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('admin.organisation_modulaire.destroy', ['organisation_modulaire' => $matiere])).'','value' => 'matiere']); ?>
                                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            
                                            <tr>
                                                <td class="module-num" data-moduleNum="<?php echo e($module->id); ?>">
                                                    <span>M<?php echo e($module->module_num); ?></span>
                                                    <i class="bi bi-pencil-square edit"></i>
                                                </td>

                                                <td>
                                                    <span data-module="<?php echo e($module->id); ?>"><?php echo e($module->module_name); ?>

                                                    </span><i class="bi bi-pencil-square edit"></i>
                                                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.delete-form','data' => ['route' => ''.e(route('admin.organisation_modulaire.destroy', ['organisation_modulaire' => $module])).'','value' => 'module']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('delete-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['route' => ''.e(route('admin.organisation_modulaire.destroy', ['organisation_modulaire' => $module])).'','value' => 'module']); ?>
                                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="d-flex justify-content-around mt-3">
                <button class="submit btn btn-primary">
                    Mettre à jour</button>
                <a class="btn btn-primary" href="<?php echo e(route('admin.organisation_modulaire.create')); ?>" role="button">
                    Ajouter un nouveau</a>
            </div>
        </div>
    </section>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.note','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        Si vous ajoutez un nouveau module dans le S1, S2 ou S3, le numéro du module aura l'air désordonné. Pour corriger
        cela, vous devrez mettre à jour manuellement le numéro du module
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.note','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('note'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        En cas de mise à jour -> cliquez sur le bouton "Modifier" et renommez n'importe quel champ dans le tableau, une
        fois terminé, cliquez sur le bouton "Mettre à jour" pour confirmer les changements.
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

     <?php $__env->slot('script', null, []); ?> 
        <script src="<?php echo e(asset('assets/js/update_se_modules.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jQuery-3.7.1.min.js')); ?>"></script>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/adminViews/se_modules.blade.php ENDPATH**/ ?>