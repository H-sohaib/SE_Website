<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['route', 'value']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['route', 'value']); ?>
<?php foreach (array_filter((['route', 'value']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<form onsubmit="confirmDelete(this , event)" class="m-0 p-0 d-inline" method="POST" action="<?php echo e($route); ?>">
    <?php echo method_field('DELETE'); ?>
    <?php echo csrf_field(); ?>
    <?php if($value): ?>
        <input type="hidden" name="delete_what" value="<?php echo e($value); ?>">
    <?php endif; ?>
    <button class="m-0 p-0 delete" type="submit"><i class="bi bi-trash-fill"></i></button>
</form>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/components/delete-form.blade.php ENDPATH**/ ?>