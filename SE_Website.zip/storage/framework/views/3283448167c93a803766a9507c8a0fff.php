<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Favicons -->
    <link href="<?php echo e(asset('assets/images/logo2.png')); ?>" rel="icon">

    <!-- Fonts -->
    
    
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/bootstrap-icons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/adminSideBar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/app_layout.css')); ?>" rel="stylesheet">

    <!-- Scripts -->

    
    <link rel="stylesheet" href="<?php echo e(asset('build/assets/app-4c010787.css')); ?>">
    <script src="<?php echo e(asset('build/assets/app-fa3b748b.js')); ?>"></script>


</head>

<body class="font-sans antialiased">
    <div>
        <!--Main Navigation-->
        <header>
            <!-- Sidebar -->
            <?php echo $__env->make('layouts.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Sidebar -->
            <!-- Navbar -->
            <nav id="main-navbar" class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
                <!-- Header wrapper -->
                <?php echo $__env->make('layouts.admin.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Header wrapper -->
            </nav>
            <!-- Navbar -->
        </header>
        <!--Main Navigation-->

        <!--Main layout-->
        <main style="margin-top: 58px;">
            <div class="container pt-4">
                <div class="bg-light border rounded-3 p-3 overflow-auto">
                    <?php echo e($slot); ?>

                </div>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.my-linkedin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('my-linkedin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </div>
        </main>
        <!--Main layout-->
    </div>



    <!-- Vendor JS Files -->
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/admin_main.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/active_current_link.js')); ?>"></script>
    <?php if(isset($script)): ?>
        <?php echo e($script); ?>

    <?php endif; ?>

</body>

</html>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/layouts/app.blade.php ENDPATH**/ ?>