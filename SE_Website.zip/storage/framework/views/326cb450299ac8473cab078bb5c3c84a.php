<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('style', null, []); ?> 
        <style>
            .portfolio {
                /* margin-top: 50px !important; */
            }

            section {
                padding: 0;
                margin: 0;
                /* overflow: auto !important; */
            }

            .portfolio .portfolio-item .portfolio-info button:hover {
                color: red !important;
            }

            .portfolio .portfolio-item .portfolio-info button {
                background-color: inherit;
            }

            .add-button {
                position: relative;
                left: 50%;
                transform: translateX(-50%)
            }

            button {
                background-color: inherit;
            }

            small {
                font-size: 10px
            }
        </style>
     <?php $__env->endSlot(); ?>
    <!-- ======= PFE Exemple Section ======= -->
    <section id="pfe" class="portfolio">
        <div class="container position-relative" data-aos="fade-up">

            <div class="section-title pb-0">
                <h3 class="mt-0">Quelques réalisation <span>PFE</span></h3>
                <p></p>
            </div>

            <div class="row">
                <div class="col-lg-12 d-flex justify-content-center">
                    <ul id="portfolio-flters">
                        <li data-filter="*" class="filter-active">Tout</li>
                        <?php $__currentLoopData = $pfe_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pfe_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-filter=".filter-<?php echo e($pfe_type->type_name); ?>"><?php echo e($pfe_type->type_name); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">
                <?php $__currentLoopData = $pfe_exemples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pfe_exemple): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('components.portfolio-card', ['pfe_exemple' => $pfe_exemple], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


        <a href="<?php echo e(route('admin.pfe_exemples.create')); ?>" class="btn btn-primary add-button">Ajouter un nouveau
            PFE</a>
    </section>




     <?php $__env->slot('script', null, []); ?> 
        <!-- Template Main JS File -->
        <script src="<?php echo e(asset('assets/js/admin_filter.js')); ?>"></script>



        <script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/glightbox.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/swiper-bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/isotope.pkgd.min.js')); ?>"></script>
        
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\WorkSpace\SE_Website\resources\views/adminViews/pfe_index.blade.php ENDPATH**/ ?>