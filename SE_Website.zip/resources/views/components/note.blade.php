<p class="text-danger mt-2"><strong>Note : </strong> {{ $slot }}
</p>
